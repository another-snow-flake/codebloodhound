export const apiKey = "synthetic-mixed-js-key";
