package demo

import org.springframework.jdbc.core.JdbcTemplate
import org.springframework.stereotype.Repository

@Repository
class NotesRepository(private val jdbc: JdbcTemplate) {
    fun search(text: String): List<Map<String, Any>> =
        jdbc.queryForList("SELECT id, title FROM notes WHERE title LIKE '%$text%'")

    fun byAuthor(author: String): List<Map<String, Any>> {
        val sql = "SELECT id, title FROM notes WHERE author = '" + author + "'"
        return jdbc.queryForList(sql)
    }

    fun find(id: Long): Map<String, Any> =
        jdbc.queryForMap("SELECT id, owner_id, title, body FROM notes WHERE id = ?", id)
}
