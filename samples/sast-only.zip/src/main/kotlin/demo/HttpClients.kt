package demo

import org.apache.http.conn.ssl.NoopHostnameVerifier
import org.apache.http.impl.client.HttpClients

fun insecureClient() = HttpClients.custom().setSSLHostnameVerifier(NoopHostnameVerifier.INSTANCE).build()
