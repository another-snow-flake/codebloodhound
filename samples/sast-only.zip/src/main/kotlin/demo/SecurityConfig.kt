package demo

import org.springframework.context.annotation.Bean
import org.springframework.context.annotation.Configuration
import org.springframework.security.config.annotation.web.builders.HttpSecurity
import org.springframework.web.cors.CorsConfiguration

@Configuration
class SecurityConfig {
    @Bean
    fun filterChain(http: HttpSecurity) = http.authorizeHttpRequests {
        it.requestMatchers("/api/admin/export").permitAll()
        it.requestMatchers("/api/admin/**").hasRole("ADMIN")
        it.anyRequest().authenticated()
    }.build()

    @Bean
    fun cors() = CorsConfiguration().apply {
        allowedOrigins = listOf("*")
        allowCredentials = true
    }
}
