package demo

import org.springframework.jdbc.core.JdbcTemplate

class OrdersDao(private val jdbc: JdbcTemplate) {
    fun delete(id: String) = jdbc.update("DELETE FROM orders WHERE id = $id")

    fun report(status: String): List<Map<String, Any>> {
        val query = """
            SELECT id, total FROM orders WHERE status = '$status'
        """
        return jdbc.queryForList(query)
    }
}
