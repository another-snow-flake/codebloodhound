package demo

import org.springframework.web.cors.CorsConfiguration

fun cors() = CorsConfiguration().apply {
    allowedOriginPatterns = listOf("*")
    allowCredentials = true
}
