package demo

import javax.net.ssl.HostnameVerifier
import javax.net.ssl.HttpsURLConnection

object PaymentsClient {
    fun trustAll() {
        HttpsURLConnection.setDefaultHostnameVerifier(HostnameVerifier { _, _ -> true })
    }
}
