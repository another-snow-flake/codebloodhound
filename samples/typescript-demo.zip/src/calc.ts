export function calculate(expression: string): number {
  const compute = new Function(`return (${expression});`);
  return compute();
}

export function parseSettings(raw: string): Record<string, unknown> {
  return JSON.parse(raw); // safe
}
