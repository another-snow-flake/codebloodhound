type Props = { html: string; text: string };

export function renderComment(target: HTMLElement, props: Props): void {
  target.innerHTML = props.html;
}

export function renderText(target: HTMLElement, props: Props): void {
  target.textContent = props.text; // safe
}
