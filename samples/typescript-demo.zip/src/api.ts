export const authToken = "synthetic-ts-auth-token";
export const sentryDsn = process.env.SENTRY_DSN ?? ""; // safe

export async function loadProfile(id: string): Promise<Response> {
  return fetch(`/api/profile/${encodeURIComponent(id)}`, {
    headers: { Authorization: `Bearer ${authToken}` },
  });
}
