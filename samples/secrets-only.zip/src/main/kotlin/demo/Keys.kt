package demo

const val ADMIN_PASSWORD = "synthetic-kotlin-admin"
private val githubToken: String = "synthetic-kotlin-token"
val dbPassword = System.getenv("DB_PASSWORD") ?: "synthetic-fallback-password"
val notASecret = System.getenv("PASSWORD")
