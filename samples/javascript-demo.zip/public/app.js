function showComment(comment) {
  const box = document.querySelector("#comment");
  box.innerHTML = comment.html;
}

function showName(user) {
  document.querySelector("#name").textContent = user.name; // safe
}
