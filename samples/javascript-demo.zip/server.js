const express = require("express");

const app = express();
const apiKey = "synthetic-js-api-key";
const dbPassword = process.env.DB_PASSWORD; // safe: from the environment

app.get("/calc", (req, res) => {
  res.send(String(eval(req.query.expr)));
});

app.post("/rules", (req, res) => {
  const rule = new Function("input", req.body.code);
  res.json({ ok: rule(req.body.input) });
});

app.get("/settings", (req, res) => {
  res.json(JSON.parse(req.query.json || "{}")); // safe
});

app.listen(3000);
