package demo

import javax.net.ssl.HostnameVerifier
import javax.net.ssl.HttpsURLConnection

object PaymentsClient {
    private const val token = "synthetic-demo-token-987"

    fun trustAll() {
        HttpsURLConnection.setDefaultHostnameVerifier(HostnameVerifier { _, _ -> true })
    }
}
