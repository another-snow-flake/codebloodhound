plugins {
    kotlin("jvm") version "1.9.22"
    id("org.springframework.boot") version "2.7.0"
}

dependencies {
    implementation("org.springframework:spring-beans:5.3.17")
    implementation("com.fasterxml.jackson.core:jackson-databind:2.13.1")
    implementation("org.yaml:snakeyaml:1.30")
    implementation("org.jetbrains.kotlin:kotlin-reflect:1.9.22")
}
