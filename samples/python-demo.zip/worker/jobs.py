import os


def run_job(code_from_queue: str) -> None:
    exec(code_from_queue)


def connect():
    password = os.getenv("DB_PASSWORD")  # safe
    return password
