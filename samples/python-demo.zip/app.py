import json
import os
import pickle
import subprocess

from flask import Flask, request

app = Flask(__name__)

DB_PASSWORD = "synthetic-python-db-password"
stripe_api_key: str = "synthetic-python-stripe-key"
API_TOKEN = os.environ["API_TOKEN"]  # safe: read from the environment


@app.get("/calc")
def calc():
    return str(eval(request.args["expr"]))


@app.post("/ping")
def ping():
    host = request.form["host"]
    subprocess.run(f"ping -c 1 {host}", shell=True)
    subprocess.run(["ping", "-c", "1", host])  # safe: no shell
    return "ok"


@app.post("/import")
def import_notes():
    notes = pickle.loads(request.data)
    settings = json.loads(request.form.get("settings", "{}"))  # safe: data-only format
    return {"notes": len(notes), "settings": settings}
