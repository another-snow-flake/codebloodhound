plugins {
    kotlin("jvm") version "1.9.22"
    id("org.springframework.boot") version "2.7.0"
}

dependencies {
    implementation("org.yaml:snakeyaml:2.2")
    implementation("com.fasterxml.jackson.core:jackson-databind:2.15.3")
}
