package demo

val apiToken: String = System.getenv("API_TOKEN") ?: error("API_TOKEN is not set")
