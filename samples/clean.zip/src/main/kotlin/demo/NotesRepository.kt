package demo

import org.springframework.jdbc.core.JdbcTemplate

class NotesRepository(private val jdbc: JdbcTemplate) {
    fun search(text: String) = jdbc.queryForList("SELECT id, title FROM notes WHERE title LIKE ?", "%$text%")

    fun find(id: Long, owner: Long) =
        jdbc.queryForMap("SELECT id, owner_id, title FROM notes WHERE id = ? AND owner_id = ?", id, owner)
}
