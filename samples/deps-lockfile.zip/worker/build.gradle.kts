dependencies {
    implementation("ch.qos.logback:logback-classic:1.3.5")
    implementation("org.springframework:spring-beans:5.3.20")
}
