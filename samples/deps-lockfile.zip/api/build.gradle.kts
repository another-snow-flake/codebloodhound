plugins {
    kotlin("jvm") version "1.9.22"
    id("org.springframework.boot") version "2.7.0"
}

val snakeyamlVersion: String by project
val textVersion = "1.9"

dependencies {
    implementation("org.yaml:snakeyaml:$snakeyamlVersion")
    implementation("org.apache.commons:commons-text:$textVersion")
    implementation("com.fasterxml.jackson.core:jackson-databind")
}
